#ifndef GEOJSONSF_WRITE_GEOJSON_H
#define GEOJSONSF_WRITE_GEOJSON_H

#include <Rcpp.h>
// #include "geojsonsf/geojson/writers/writers.hpp"
// #include "geojsonsf/geometrycollection/geometrycollection.hpp"

// TODO( remove once spatialwidget v0.2 is on CRAN)
// TODO( deprecate this in favour of geojsonsf/geojson/writers/write_geojson)

#include "geojsonsf/geojson/writers/write_geojson.hpp"

#endif
