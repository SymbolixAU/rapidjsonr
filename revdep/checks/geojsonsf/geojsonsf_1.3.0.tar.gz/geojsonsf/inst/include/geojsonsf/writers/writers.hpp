#ifndef GEOJSONSF_WRITERS_H
#define GEOJSONSF_WRITERS_H

// TODO( remove once spatialwidget v0.2 is on CRAN)

#include <Rcpp.h>
#include "geojsonsf/geojson/writers/writers.hpp"

#endif
