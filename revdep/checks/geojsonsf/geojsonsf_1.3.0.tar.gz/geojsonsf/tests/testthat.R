library(testthat)
library(geojsonsf)

test_check("geojsonsf")
